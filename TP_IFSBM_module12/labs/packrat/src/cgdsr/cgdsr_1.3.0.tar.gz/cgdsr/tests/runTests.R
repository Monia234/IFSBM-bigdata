library(testthat)
library(cgdsr)
test_package("cgdsr")
